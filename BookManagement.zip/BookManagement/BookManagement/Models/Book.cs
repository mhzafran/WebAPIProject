﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BookBorrowingSystemAPI.Models
{
    public class Book
    {
        [Key]
        public int BookID { get; set; }

        [Required]
        [MaxLength(255)]  // Adjusted length for book title
        public string Title { get; set; }

        [Required]
        [MaxLength(100)]  // Adjusted length for author name
        public string Author { get; set; }

        [Required]
        [MaxLength(50)]  // Adjusted length for book status
        public string Status { get; set; }
    }
}
