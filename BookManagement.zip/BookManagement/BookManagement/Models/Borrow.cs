﻿using System;
using System.ComponentModel.DataAnnotations;

namespace BookBorrowingSystemAPI.Models
{
    public class Borrow
    {
        [Key]
        public int BorrowID { get; set; }

        [Required]
        public int BookID { get; set; }

        [Required]
        [MaxLength(100)]  // Adjusted length for username
        public string UserName { get; set; }

        public DateTime BorrowDate { get; set; }


    }
}
