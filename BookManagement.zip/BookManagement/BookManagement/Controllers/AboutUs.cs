﻿using BookBorrowingSystemAPI.Data;
using BookBorrowingSystemAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

public class HomeController : Controller
{
    public IActionResult AboutUs()
    {
        return View();  // This will render AboutUs.cshtml
    }
}
